// Importaciones

import swal from "sweetalert"
import axios from "axios";
import { useState,useEffect }  from "react";
import { useNavigate } from "react-router-dom";
const URI = "http://localhost:8080/solicitudes/"
const URI1 = "http://localhost:8080/citas/"

let headers = {
    "usuario" : sessionStorage.getItem("usuario"),
    "clave"   : sessionStorage.getItem("clave")
  };

const Solicitudes = () => {

    const [solicitudes, setSolicitudes] = useState([])
    const navigate = useNavigate();
    
    useEffect(() =>{ getSolicitudes()})

    // Función para obtener los registros de la tabla de "solicitudes"
    const getSolicitudes = async () =>{
        try {
            const res = await axios({
                method : "GET",
                url : URI + "consulta_solicitud?idmed="+sessionStorage.getItem("usuario"),
                headers: headers 
               
            });
            
                setSolicitudes(res.data)
            
        }
        catch (error) {
            swal("No tiene Acceso a esta Opción!", "Presiona el butón!", "error");
            navigate("/");
        }
    }

    // Función para Borrar Solicitud
    const deleteSolicitud = async (id) => { // Recibe el ID del registro
      swal(
          {
              title: "Eliminar Registro",
              text: "Está seguro de eliminar registro?",
              icons: "Warning",
              buttons: true,
              dangerMode: true,
          })
          .then(async (willDelete) =>{
              if (willDelete){
                  const res = await axios({
                      method: "DELETE",
                      url: URI + id,
                      headers: headers 
                  });
                  swal("El resgistro se eliminó satisfactoriamente",{ 
                      icon: "success",
                  });
                  getSolicitudes()
              } else{
                  swal("El registro no se borró")
              }
          });
      
  }

  // Función para regresar al Menu
  const salir = () => {
    navigate("/")
  }

// Función para enviar solicitud a tabla "citas" y eliminar registro de solicitud
 const editar = async (idsol,nom,fenac,ident,feat,hor,cor,idm) => {   

    // Función para enviar solicitud
    try{
      const InsertCita = await axios({
        method: "POST",
        url: URI1,
        data: {
          nombre_cita: nom, fecha_nac_cita: fenac, identificacion_cita: ident, fecha_at_cita: feat, hora_at_cita: hor, correo_cita: cor, 
          medico: {id_medico: idm, identificacion_medico: null, nombre_medico: null, rm_medico: null, movil_medico: null, correo_medico: null, clave_medico: null}
        },
        headers: headers 
 
      });

      swal("La solicitud se ha registrado correctamente!", "Presiona el botón para salir!", "success");
    }
    catch(error){
       swal("Error, la solicitud no se envío!", "Presiona el butón!", "error");
       navigate("/solicitudes");
    }


    // Método para borrar solicitud al enviarla
    try{
      const borrarSolicitud = await axios({
        method: "DELETE",
        url: URI + idsol,
        headers: headers 
      });
    }
    catch(error){
        swal("No tiene Acceso a esta Opción!", "Presiona el butón!", "error");
        navigate("/solicitudes");
    }


      navigate("/solicitudes");
    };


    return (
    
    <div className='container'>
      <br></br>
      <h3>Solicitudes</h3><br></br>
        <div className='row'>
            <div className='col'>
                <table className='table'>
                    <thead className='table-primary'>
                        <tr>
                            <th>Id</th>
                            <th>Nombre</th>
                            <th>Fecha Nac</th>
                            <th>Identificación</th>
                            <th>Fecha Atención</th>
                            <th>Hora Atención</th>
                            <th>Correo</th>
                            <th>Medico</th>
                        </tr>
                    </thead>
                    <tbody>
                        { solicitudes.map ( (solicitud) => (
                           
                            <tr key={ solicitud.id_solicitud}>
                                <td> { solicitud.id_solicitud } </td>
                                <td> { solicitud.nombre_solicitud } </td>
                                <td> { solicitud.fecha_nac_solicitud.substring(0,10) } </td>
                                <td> { solicitud.identificacion_solicitud } </td>
                                <td> { solicitud.fecha_at_solicitud.substring(0,10) } </td>
                                <td> { solicitud.hora_at_solicitud.substring(0,5) } </td>
                                <td> { solicitud.correo_solicitud } </td>
                                <td> { solicitud.medico.nombre_medico} </td>
                                <td>
                                   <button onClick={() => editar(solicitud.id_solicitud,solicitud.nombre_solicitud,
                                   solicitud.fecha_nac_solicitud,solicitud.identificacion_solicitud,
                                   solicitud.fecha_at_solicitud,solicitud.hora_at_solicitud,solicitud.correo_solicitud,
                                   solicitud.medico.id_medico
                                   )}
                                    className='btn btn-info'><i className="fa-regular fa-paper-plane"></i></button>
                                   <button onClick={() => deleteSolicitud(solicitud.id_solicitud)} className='btn btn-danger'><i className="fas fa-trash-alt"></i></button>
                                </td>
                            </tr>
                        )) }
                    </tbody>
                </table>
            </div>    
        </div>
        <form className="d-flex">
            <button className="btn btn-primary" type="button" onClick={salir}>
                Regresar
            </button>
        </form>
    </div>
    );
};
export default Solicitudes;