// Importaciones

import swal from "sweetalert"
import axios from "axios";
import { useState,useEffect }  from "react";
import { Link, useNavigate} from "react-router-dom";
const URI = "http://localhost:8080/citas/"
const URI1 = "http://localhost:8080/solicitudes/"

let headers = {
    "usuario" : sessionStorage.getItem("usuario"),
    "clave"   : sessionStorage.getItem("clave")
  };

const Citas = () => {
    const navigate = useNavigate();
    const [citas, setCitas] = useState([])
    useEffect(() =>{ getCitas()})

    // Función para obtener los registros de la tabla de citas
    const getCitas = async () =>{
        try {
            const res = await axios({
                method : "GET",
                url : URI + "consulta_cita?idmed="+sessionStorage.getItem("usuario"),
                headers: headers 
               
            });
            
                setCitas(res.data)
            
        }
        catch (error) {
            swal("No tiene Acceso a esta Opción!", "Presiona el butón!", "error");
            navigate("/");
        }
    }

    // Función para Borrar Cita
    const deleteCita = async (id) => {
        swal(
            {
                title: "Eliminar Registro",
                text: "Está seguro de eliminar registro?",
                icons: "Warning",
                buttons: true,
                dangerMode: true,
            })
            .then(async (willDelete) =>{
                if (willDelete){
                    const res = await axios({
                        method: "DELETE",
                        url: URI + id,
                        headers: headers 
                    });
                    swal("El resgistro se eliminó satisfactoriamente",{ 
                        icon: "success",
                    });
                    getCitas()
                } else{
                    swal("El registro no se borró")
                }
            });
        
    }

    // Función para regresar al Menu
    const salir = () => {
        navigate("/")
    }

    return (
        <div className='container'>
        <div className='row'>
            <div className='col'>
                <Link to="/crear" className='btn btn-primary mt-2 mb-2'><i className="fas fa-plus"></i></Link>
                <table className='table'>
                    <thead className='table-primary'>
                        <tr>
                            <th>Id</th>
                            <th>Nombre</th>
                            <th>Fecha Nac</th>
                            <th>Identificación</th>
                            <th>Fecha Atención</th>
                            <th>Hora Atención</th>
                            <th>Correo</th>
                            <th>Medico</th>
                        </tr>
                    </thead>
                    <tbody>
                        { citas.map ( (cita) => (
                           
                            <tr key={ cita.id_cita}>
                                <td> { cita.id_cita } </td>
                                <td> { cita.nombre_cita } </td>
                                <td> { cita.fecha_nac_cita.substring(0,10) } </td>
                                <td> { cita.identificacion_cita } </td>
                                <td> { cita.fecha_at_cita.substring(0,10) } </td>
                                <td> { cita.hora_at_cita.substring(0,5) } </td>
                                <td> { cita.correo_cita } </td>
                                <td> { cita.medico.nombre_medico} </td>
                                <td>
                                   <Link to={`/editar/${cita.id_cita}`} className='btn btn-info'><i className="fas fa-edit"></i></Link>
                                   <button onClick={() => deleteCita(cita.id_cita)} className='btn btn-danger'><i className="fas fa-trash-alt"></i></button>
                                </td>
                            </tr>
                        )) }
                    </tbody>
                </table>
            </div>    
        </div>
        <form className="d-flex">
            <button className="btn btn-primary" type="button" onClick={salir}>
                Regresar
            </button>
        </form>
    </div>
    );
};
export default Citas;