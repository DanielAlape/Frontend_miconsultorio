// Importaciones

import swal from "sweetalert"
import axios from "axios";
import { useState,useEffect }  from "react";
import { Link, useNavigate} from "react-router-dom";
const URI = "http://localhost:8080/solicitudes/"
const URI1 = "http://localhost:8080/medico/";

let headers = {
    "usuario" : sessionStorage.getItem("usuario"),
    "clave"   : sessionStorage.getItem("clave")
  };

const Paciente = () => {

  const [id_solicitud, setId_solicitud] = useState("");
  const [nombre_solicitud, setNombre_solicitud] = useState("");
  const [fecha_nac_solicitud, setFecha_nac_solicitud] = useState("");
  const [identificacion_solicitud, setIdentificacion_solicitud] = useState("");
  const [fecha_at_solicitud, setFecha_at_solicitud] = useState("");
  const [hora_at_solicitud, setHora_at_solicitud] = useState("");
  const [correo_solicitud, setCorreo_solicitud] = useState("");
  const [medico, setMedico] = useState([])
  const [medicos, setMedicos] = useState([])
  const navigate = useNavigate();

  // Función para crear solicitud
  const guardar = async (e) => {
    e.preventDefault();

    const insertSolicitud = await axios({
        method: "POST",
        url: URI,
        data: {
            id_solicitud: id_solicitud, nombre_solicitud: nombre_solicitud, fecha_nac_solicitud: fecha_nac_solicitud, identificacion_solicitud: identificacion_solicitud,
            fecha_at_solicitud: fecha_at_solicitud, hora_at_solicitud: hora_at_solicitud, correo_solicitud: correo_solicitud, 
            medico: {id_medico: medico, identificacion_medico: null, nombre_medico: null, rm_medico: null, movil_medico: null, correo_medico: null, clave_medico: null}
        },
      });

    swal("Solicitud enviada!", "Presiona el botón para salir!", "success");  
    navigate("/"); // Redirección al Menu
  };

   // Función para llenar la lista de "Medicos"
   const llenarLista = async () =>{
    try {
        
        const res1 = await axios({
            method : "GET",
            url : URI1 + "list"           
        });
        
        setMedicos(res1.data)
        
    }
    catch (error) {
    }
  }

  // Función para regresar al componente Menu
  const salir = () => {
    navigate("/")
  }

  llenarLista();


    return (
        <div>
        <table className='table'>
          <tbody>
             <td>
              <form className="d-flex justify-content-start">
                <button className="btn btn-primary" type="button" onClick={salir}>
                    Regresar
               </button>
              </form>
              </td>
          </tbody>
        </table>
        <h3>Solicitar Cita</h3>
        <div className="container col-2">
        <form onSubmit={guardar}> 
            <div className="mb-3">
            <label className="form-label">Nombre</label>
            <textarea
                value={nombre_solicitud}
                onChange={(e) => setNombre_solicitud(e.target.value)}
                type="text"
                className="form-control"
                placeholder="Digite su nombre"
                required
                onInvalid={e => e.target.setCustomValidity('El campo Nombre es obligatorio')}
                onInput={e => e.target.setCustomValidity('')}
            />
            </div>
            <div className="mb-3">
            <label className="form-label">Fecha de Nacimiento</label>
            <textarea
                value={fecha_nac_solicitud}
                onChange={(e) => setFecha_nac_solicitud(e.target.value)}
                type="text"
                className="form-control"
                placeholder="Digite su fecha de nacimiento"
                required
                onInvalid={e => e.target.setCustomValidity('El campo Fecha de Nacimiento es obligatrio')}
                onInput={e => e.target.setCustomValidity('')}
            />
            </div>
            <div className="mb-3">
            <label className="form-label">Identificación</label>
            <textarea
                value={identificacion_solicitud}
                onChange={(e) => setIdentificacion_solicitud(e.target.value)}
                type="text"
                className="form-control"
                placeholder="Digite su documento de identidad"
                required
                onInvalid={e => e.target.setCustomValidity('El campo Identificación es obligatrio')}
                onInput={e => e.target.setCustomValidity('')}
            />
            </div>
            <div className="mb-3">
            <label className="form-label">Fecha de Atención</label>
            <textarea
                value={fecha_at_solicitud}
                onChange={(e) => setFecha_at_solicitud(e.target.value)}
                type="text"
                className="form-control"
                placeholder="Digite la fecha de atención"
                required
                onInvalid={e => e.target.setCustomValidity('El campo Fecha de Atención es obligatrio')}
                onInput={e => e.target.setCustomValidity('')}
            />
            </div>
            <div className="mb-3">
            <label className="form-label">Hora de Atención</label>
            <textarea
                value={hora_at_solicitud}
                onChange={(e) => setHora_at_solicitud(e.target.value)}
                type="text"
                className="form-control"
                placeholder="Digite la hora de atención"
                required
                onInvalid={e => e.target.setCustomValidity('El campo Hora de Atención es obligatrio')}
                onInput={e => e.target.setCustomValidity('')}
            />
            </div>
            <div className="mb-3">
            <label className="form-label">Correo</label>
            <textarea
                value={correo_solicitud}
                onChange={(e) => setCorreo_solicitud(e.target.value)}
                type="text"
                className="form-control"
                placeholder="Digite su correo electrónico"
                required
                onInvalid={e => e.target.setCustomValidity('El campo Correo es obligatrio')}
                onInput={e => e.target.setCustomValidity('')}
            />
            </div>
            <div className="mb-3">
            <label className="form-label">Medico</label>
            <select
                value={medico}
                onChange={(e) => setMedico(e.target.value)}
                className="form-control">
            { medicos.map ( (medico) => (
                    <option value={medico.id_medico}>{medico.nombre_medico}</option>
                )) }
            </select>
            </div>
            <button type="submit" className="btn btn-primary">
              Guardar
            </button>
        </form>
      </div>
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      </div>
    );
};
export default Paciente;