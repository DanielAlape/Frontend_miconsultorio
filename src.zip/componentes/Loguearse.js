// Importaciones

import swal from "sweetalert"; 
import axios from "axios"; 
import { useState } from "react"; 
import { useNavigate } from "react-router-dom"; 
const URI = "http://localhost:8080/medico/";

const Loguearse = () => {

    const navigate = useNavigate();
    const [medico, setMedico] = useState([])
    const [id_medico, setId_medico] = useState("");
    const [clave_medico, setClave_medico] = useState("");

    const guardar = async (e) => { // Función "guardar"
        e.preventDefault();
        
        try {          
            const res = await axios({ // Consumo del recurso "login"
                method : "GET",
                url: URI + "login?usuario="+id_medico+"&clave="+clave_medico
            });          
            setMedico(res.data)
            if (res.data.id_medico==null) {
                
                swal("Medico NO Autorizado!", "Presiona el butón!", "error");
                navigate("/"); // Lo redirecciona al componente Menu
                
            } else {
               sessionStorage.setItem("usuario",id_medico); // Guarda los valores en las variables de sesión
               sessionStorage.setItem("clave",clave_medico);
               swal("Bienvenido "+res.data.nombre_medico+"!", "Presiona el butón!", "success"); // Mensaje de saludo
               navigate("/"); // Redirecciona al Menu
            }
        }
        catch (error) {
            swal("Operación NO realizada")
        }

      };


    return (
        <div>
        <h3>Login</h3>
        <div className="container col-2">
        <form onSubmit={guardar}>
            
            <div className="mb-3">
                <label className="form-label">ID</label>
                <textarea
                    value={id_medico}
                    onChange={(e) => setId_medico(e.target.value)}
                    type="text"
                    maxLength={15}
                    required
                    onInvalid={e => e.target.setCustomValidity('El campo Id medico es obligatorio')}
                    onInput={e => e.target.setCustomValidity('')}
                    className="form-control"
            />
            </div>
            <div className="mb-3">
                <label className="form-label">Clave</label>
                <input
                    value={clave_medico}
                    onChange={(e) => setClave_medico(e.target.value)}
                    type="password"
                    maxLength={50}
                    required
                    onInvalid={e => e.target.setCustomValidity('El campo Contraseña  es obligatorio')}
                    onInput={e => e.target.setCustomValidity('')}
                    className="form-control"
                />
            </div>
            <button type="submit" className="btn btn-primary">
            Login
            </button>
        </form>
    </div>
    </div>
    );
};
export default Loguearse;
    