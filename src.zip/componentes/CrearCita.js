import swal from "sweetalert"
import axios from "axios";
import { useState,useEffect }  from "react";
import { useNavigate} from "react-router-dom";
const URI = "http://localhost:8080/citas/"
const URI1 = "http://localhost:8080/medico/";

let headers = {
    "usuario" : sessionStorage.getItem("usuario"),
    "clave"   : sessionStorage.getItem("clave")
  };
  
const CrearCita = () => {

  const [id_cita, setId_cita] = useState("");
  const [nombre_cita, setNombre_cita] = useState("");
  const [fecha_nac_cita, setFecha_nac_cita] = useState("");
  const [identificacion_cita, setIdentificacion_cita] = useState("");
  const [fecha_at_cita, setFecha_at_cita] = useState("");
  const [hora_at_cita, setHora_at_cita] = useState("");
  const [correo_cita, setCorreo_cita] = useState("");
  const [medico, setMedico] = useState([])
  const [medicos, setMedicos] = useState([])
  const navigate = useNavigate();

  // Función para crear cita
  const guardar = async (e) => {
    e.preventDefault();

    const insertCita = await axios({
        method: "POST",
        url: URI,
        data: {
          id_cita: id_cita, nombre_cita: nombre_cita, fecha_nac_cita: fecha_nac_cita, identificacion_cita: identificacion_cita, fecha_at_cita: fecha_at_cita, hora_at_cita: hora_at_cita, correo_cita: correo_cita, 
          medico: {id_medico: medico, identificacion_medico: null, nombre_medico: null, rm_medico: null, movil_medico: null, correo_medico: null, clave_medico: null}
        },
        headers: headers 
      });
      
    swal("La cita se ha registrado correctamente!", "Presiona el botón para salir!", "success");
    navigate("/citas");
  };

  // Función para llenar la lista de "Medicos"
  const llenarLista = async () =>{
    try {
        
        const res1 = await axios({
            method : "GET",
            url : URI1 + "list"
        });
        
        setMedicos(res1.data)
        
    }
    catch (error) {
        //swal("No tiene Acceso a esta Opción1!", "Presiona el butón!", "error");
        //navigate("/");
    }
  }

  // Función para regresar al componente Citas
  const salir = () => {
    navigate("/citas")
  }

  llenarLista(); // Se llama a la función para que se muestren los objetos "Medico"

    return (
      <div>
      <table className='table'>
        <tbody>
           <td>
            <form className="d-flex justify-content-start">
              <button className="btn btn-primary" type="button" onClick={salir}>
                  Regresar
             </button>
            </form>
            </td>
        </tbody>
      </table>
      <h3>Crear Cita</h3>
      <div className="container col-2">
      <form onSubmit={guardar}> 
          <div className="mb-3">
          <label className="form-label">Nombre</label>
          <textarea
              value={nombre_cita}
              onChange={(e) => setNombre_cita(e.target.value)}
              type="text"
              className="form-control"
              placeholder="Digite su nombre"
              required
              onInvalid={e => e.target.setCustomValidity('El campo Nombre es obligatorio')}
              onInput={e => e.target.setCustomValidity('')}
          />
          </div>
          <div className="mb-3">
          <label className="form-label">Fecha de Nacimiento</label>
          <textarea
              value={fecha_nac_cita}
              onChange={(e) => setFecha_nac_cita(e.target.value)}
              type="text"
              className="form-control"
              placeholder="Digite su fecha de nacimiento"
              required
              onInvalid={e => e.target.setCustomValidity('El campo Fecha de Nacimiento es obligatrio')}
              onInput={e => e.target.setCustomValidity('')}
          />
          </div>
          <div className="mb-3">
          <label className="form-label">Identificación</label>
          <textarea
              value={identificacion_cita}
              onChange={(e) => setIdentificacion_cita(e.target.value)}
              type="text"
              className="form-control"
              placeholder="Digite su documento de identidad"
              required
              onInvalid={e => e.target.setCustomValidity('El campo Identificación es obligatrio')}
              onInput={e => e.target.setCustomValidity('')}
          />
          </div>
          <div className="mb-3">
          <label className="form-label">Fecha de Atención</label>
          <textarea
              value={fecha_at_cita}
              onChange={(e) => setFecha_at_cita(e.target.value)}
              type="text"
              className="form-control"
              placeholder="Digite la fecha de atención"
              required
              onInvalid={e => e.target.setCustomValidity('El campo Fecha de Atención es obligatrio')}
              onInput={e => e.target.setCustomValidity('')}
          />
          </div>
          <div className="mb-3">
          <label className="form-label">Hora de Atención</label>
          <textarea
              value={hora_at_cita}
              onChange={(e) => setHora_at_cita(e.target.value)}
              type="text"
              className="form-control"
              placeholder="Digite la hora de atención"
              required
              onInvalid={e => e.target.setCustomValidity('El campo Hora de Atención es obligatrio')}
              onInput={e => e.target.setCustomValidity('')}
          />
          </div>
          <div className="mb-3">
          <label className="form-label">Correo</label>
          <textarea
              value={correo_cita}
              onChange={(e) => setCorreo_cita(e.target.value)}
              type="text"
              className="form-control"
              placeholder="Digite su correo electrónico"
              required
              onInvalid={e => e.target.setCustomValidity('El campo Correo es obligatrio')}
              onInput={e => e.target.setCustomValidity('')}
          />
          </div>
          <div className="mb-3">
          <label className="form-label">Medico</label>
          <select
              value={medico}
              onChange={(e) => setMedico(e.target.value)}
              className="form-control">
          { medicos.map ( (medico) => (
                  <option value={medico.id_medico}>{medico.nombre_medico}</option>
              )) }
          </select>
          </div>
          <button type="submit" className="btn btn-primary">
            Guardar
          </button>
      </form>
    </div>
    <br></br>
    <br></br>
    <br></br>
    <br></br>
    </div>
  );
};
export default CrearCita;