// Importaciones
import swal from "sweetalert"; 
import { useNavigate } from "react-router-dom";
import Login from "../componentes/Loguearse"

let headers = { // Aquí se capturan las variables de sesión
  "usuario" : sessionStorage.getItem("usuario"),
  "clave"   : sessionStorage.getItem("clave")
};

const Menu = (props) => { // Este "props" recibe las rutas

  const navigate = useNavigate();

  const ingresar = () => {
    navigate("/login") // Redirección al componente "Loguearse"
  }

  const cita = () => {
    navigate("/citas") // Redirección al componente "Citas"
  }

  const solicitud = () => {
    navigate("/solicitudes") // Redirección al componente "Solicitudes"
  }

  const paciente = () => {
    navigate("/paciente") // Redirección al componente "Paciente"
  }

  const salir = () => { // Limpia las varibles de sesion
  sessionStorage.clear() 
  swal("Sesión Finalizada!", "Presiona el butón para cerrar!", "success");
  navigate("/") // Redirecciona al Menu
  }

  // Código para el consumo de recursos del componente
    return ( 
      <div>
        <nav className="navbar navbar-expand-lg ">  
        <div className="container-fluid"> 
          <ul className="navbar-nav me-auto mb-2 mb-lg-0"> 
            <form className="d-flex">
              <button className="btn btn-outline-success" type="button" onClick={paciente}> 
                Solicitar Cita 
              </button>
            </form>
            <form className="d-flex">
              <button className="btn btn-outline-success" type="button" onClick={solicitud}> 
                Solicitudes 
              </button>
            </form>
            <form className="d-flex">
              <button className="btn btn-outline-success" type="button" onClick={cita}> 
                Citas 
              </button>
            </form>
            <form className="d-flex">
              <button className="btn btn-outline-primary" type="button" onClick={ingresar}> 
                Login 
              </button>
            </form> 
            <form className="d-flex">
              <button className="btn btn-outline-danger" type="button" onClick={salir}> 
                Logout 
              </button>
            </form> 
          </ul> 
        </div> 
        </nav> 
        <div>
        {  
          props.ruta==="login"? <Login headers={headers}/>:""
        }
        </div>
        </div>
    ); 
}; 
export default Menu; 
        