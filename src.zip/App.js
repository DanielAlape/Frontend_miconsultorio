
import './App.css';
import MenuPpal from "./componentes/Menu"
import PagCitas from "./componentes/Citas"
import PagSolicitudes from "./componentes/Solicitudes"
import Paciente from "./componentes/Paciente"
import CrearCita from "./componentes/CrearCita"
import EditarCita from "./componentes/EditarCita"
import { BrowserRouter, Route, Routes} from "react-router-dom"

function App() {
  return ( 
    <div className="App">
      <div className='App-header'> 
      <BrowserRouter>
        <Routes>
        <Route path="/" element={<MenuPpal />} />
        <Route path="/login" element={<MenuPpal ruta="login" />} />
        <Route path="/citas" element={<PagCitas />} />
        <Route path="/solicitudes" element={<PagSolicitudes />} />
        <Route path="/paciente" element={<Paciente  />} />
        <Route path="/crear" element={<CrearCita />} />
        <Route path="/editar/:id" element={<EditarCita  />} />

        </Routes>  
      </BrowserRouter> 
      </div>
    </div>
  );
}

export default App;
